# Interactive-Mandelbrot
University project, interactive Mandelbrot set multi threaded using openMP.
