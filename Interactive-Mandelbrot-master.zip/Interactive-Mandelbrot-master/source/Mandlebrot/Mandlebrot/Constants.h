#if !defined(MYLIB_CONSTANTS_H)
#define MYLIB_CONSTANTS_H 1

//Program constants
static const int iterationsCap = 2000;
static const int VIEW_HEIGHT = 535;
static const int VIEW_WIDTH = 1075;

#endif 